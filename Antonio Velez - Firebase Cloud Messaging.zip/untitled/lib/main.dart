import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'message.dart';
import 'message_list_entry.dart';
import 'send_message.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  final String appTitle = 'ESTG Instant Messaging';

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: appTitle,

    home: MainPage(appTitle),
  );
}
class MainPage extends StatelessWidget {
  final String appTitle;
  const MainPage(this.appTitle, {Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(appTitle)),
    body:
        const MessagingWidget(),





  );
}
class MessagingWidget extends StatefulWidget {

  const MessagingWidget({Key key}) : super(key: key);
  @override
  MessagingWidgetState createState() => MessagingWidgetState();
}
class MessagingWidgetState extends State<MessagingWidget> {
  final FirebaseMessaging messaging = FirebaseMessaging.instance;
  final List<Message> messages = [];
  final TextEditingController textEditingController =
  TextEditingController();
  final ScrollController listScrollController = ScrollController();
  String _token = "";
  Future<void> setup() async {
    messaging.getToken().then((value) => debugPrint(value));
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        setState(() {
          messages.add(
              Message(message.notification.title,
                  message.notification.body));
        });
      }
    });
    // Subscribe a topic called 'all'
    messaging.subscribeToTopic("all");
    messaging.getToken().then((token) => _token = token);
  }

  @override
  void initState() {
    super.initState();
    setup();
  }
  @override
  Widget build(BuildContext context) {
    final List<MessageListEntry> list = messages.map((_message) {
      String who = (_token == _message.title) ? "- Eu Disse:" : "- Alguém Disse:";
      return MessageListEntry(who, _message.body, _message.title ==
          _token);
    }).toList();
    return SafeArea(
        child: Column(
            children: <Widget>[
              Flexible(
                  child: ListView(
                      padding: const EdgeInsets.all(12.0),
                      controller: listScrollController,
                      children: list
                  )
              ),
              Row(children: [
                Flexible(child: Container(
                  margin: const EdgeInsets.only(left: 16.0),
                  child: TextField(
                    style: const TextStyle(fontSize: 15.0),
                    controller: textEditingController,
                    decoration: const InputDecoration.collapsed(
                        hintText: ('Digite a sua mensagem...'),
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                    enabled: true,
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(8.0),
                  child: IconButton(
                    icon: const Icon(Icons.send,color: Colors.blue,),
                    onPressed: () {
                      sendNotification(_token, textEditingController.text);
                      textEditingController.clear();
                      },
                  ),
                ),

              ],)
            ]
        )
    );

  }
}
