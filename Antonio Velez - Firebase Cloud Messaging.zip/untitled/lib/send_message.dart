import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

void sendNotification(title, body) async {
  // Replace <Server-Token> with server token from firebase console settings.
  await http.post(
    Uri.parse("https://fcm.googleapis.com/fcm/send"),
    headers: <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'key=AAAALpfG6ws:APA91bHwq9T_mc7GD3RKW_6Fo3arlSFbL5IZmbkv9B__TbGO2PRtVnK0sTev7034vh_QRT6_FO7RnMz_n-HiHRZ_8BnicxAeUuYexPBNdju8wVR1qmXHkyWpG3djoaP5t6FB1U-y32Xh',
    },
    body: jsonEncode(
      <String, dynamic>{
        'notification': <String, dynamic>{'body': body, 'title':
        title},
        'priority': 'high',
        'data': <String, dynamic>{
          'click_action': 'FLUTTER_NOTIFICATION_CLICK',
          'id': '1',
          'status': 'done'
        },
        'to': '/topics/all',
      },
    ),
  );
}