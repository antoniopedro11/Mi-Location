import 'package:flutter/material.dart';
class MessageListEntry extends Container {
  MessageListEntry(
      String who,
      String message,
      bool me, {Key key}
      ) : super(
    key: key, padding: const EdgeInsets.all(8),
    child: Row(
      mainAxisAlignment: me ? MainAxisAlignment.end :
      MainAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  who,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),

              ),

              Text(
                message,
                style: TextStyle(
                  color: Colors.grey[500],
                ),
              ),
            ],
          ),
        ),

      ],
    ),
  );
}
